function login(element) {
    element.innerText = "Logout"
}
function hide(element) {
    element.remove();
}